import { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import CrewManagement from './components/CrewManagement';
import CrewLicense from './components/CrewLicense';
import CrewTraining from './components/CrewTraining';
import FlightManagement from './components/FlightManagement';
import FlightRoute from './components/FlightRoute';
import FlightAircraft from './components/FlightAircraft';
import ScheduleGantt from './components/ScheduleGantt';
import ComplianceCheck from './components/ComplianceCheck';
import ComplianceViolations from './components/ComplianceViolations';
import ComplianceReports from './components/ComplianceReports';
import ReportCenter from './components/ReportCenter';
import ReportExport from './components/ReportExport';
import SystemSettings from './components/SystemSettings';
import Login from './components/Login';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeView, setActiveView] = useState('dashboard');

  if (!isLoggedIn) {
    return <Login onLogin={() => setIsLoggedIn(true)} />;
  }

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />;
      case 'crew':
      case 'crew-list':
        return <CrewManagement />;
      case 'crew-license':
        return <CrewLicense />;
      case 'crew-training':
        return <CrewTraining />;
      case 'flight':
      case 'flight-list':
        return <FlightManagement />;
      case 'flight-route':
        return <FlightRoute />;
      case 'flight-aircraft':
        return <FlightAircraft />;
      case 'schedule':
        return <ScheduleGantt />;
      case 'compliance':
      case 'compliance-rules':
        return <ComplianceCheck />;
      case 'compliance-violations':
        return <ComplianceViolations />;
      case 'compliance-reports':
        return <ComplianceReports />;
      case 'report':
      case 'report-stats':
        return <ReportCenter />;
      case 'report-export':
        return <ReportExport />;
      case 'settings':
      case 'settings-basic':
      case 'settings-account':
      case 'settings-rules':
        return <SystemSettings activeView={activeView} />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout activeView={activeView} onViewChange={setActiveView}>
      {renderView()}
    </Layout>
  );
}