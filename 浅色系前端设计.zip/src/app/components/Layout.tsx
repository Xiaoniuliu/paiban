import React, { useState } from 'react';
import { Plane, Home, Users, Calendar, CheckCircle, BarChart3, Settings, Menu } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeView: string;
  onViewChange: (view: string) => void;
}

export default function Layout({ children, activeView, onViewChange }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const menuItems = [
    { id: 'dashboard', name: '首页', icon: Home, path: '/' },
    {
      id: 'crew',
      name: '机组管理',
      icon: Users,
      children: [
        { id: 'crew-list', name: '机组列表', path: '/crew/list' },
        { id: 'crew-license', name: '资质证照', path: '/crew/license' },
        { id: 'crew-training', name: '培训记录', path: '/crew/training' }
      ]
    },
    {
      id: 'flight',
      name: '航班管理',
      icon: Plane,
      children: [
        { id: 'flight-list', name: '航班列表', path: '/flight/list' },
        { id: 'flight-route', name: '航线管理', path: '/flight/route' },
        { id: 'flight-aircraft', name: '飞机档案', path: '/flight/aircraft' }
      ]
    },
    { id: 'schedule', name: '排班管理', icon: Calendar, path: '/schedule' },
    {
      id: 'compliance',
      name: '合规校验',
      icon: CheckCircle,
      children: [
        { id: 'compliance-rules', name: '校验规则', path: '/compliance/rules' },
        { id: 'compliance-violations', name: '违规处理', path: '/compliance/violations' },
        { id: 'compliance-reports', name: '报告导出', path: '/compliance/reports' }
      ]
    },
    {
      id: 'report',
      name: '报表中心',
      icon: BarChart3,
      children: [
        { id: 'report-stats', name: '统计报表', path: '/report/stats' },
        { id: 'report-export', name: '数据导出', path: '/report/export' }
      ]
    },
    {
      id: 'settings',
      name: '系统设置',
      icon: Settings,
      children: [
        { id: 'settings-basic', name: '基础配置', path: '/settings/basic' },
        { id: 'settings-account', name: '账号管理', path: '/settings/account' },
        { id: 'settings-rules', name: '规则配置', path: '/settings/rules' }
      ]
    }
  ];

  return (
    <div className="flex h-screen bg-background">
      {/* 侧边栏 */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-0'
        } transition-all duration-300 bg-sidebar border-r border-sidebar-border flex flex-col overflow-hidden`}
      >
        <div className="flex flex-col h-full">
          {/* Logo 区域 */}
          <div className="p-6 border-b border-sidebar-border">
            <div className="flex items-center gap-3">
              <Plane className="w-8 h-8 text-primary flex-shrink-0" />
              <div className="min-w-0">
                <h1 className="text-base font-semibold text-foreground whitespace-nowrap">全球通货运排班系统</h1>
                <p className="text-xs text-muted-foreground whitespace-nowrap">GLOBAL CREW SCHEDULING</p>
              </div>
            </div>
          </div>

          {/* 导航菜单 */}
          <nav className="flex-1 overflow-y-auto p-4 space-y-1">
            {menuItems.map((item) => (
              <div key={item.id}>
                <button
                  onClick={() => onViewChange(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors ${
                    activeView === item.id || (item.children && item.children.some(child => child.id === activeView))
                      ? 'bg-primary text-primary-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.name}</span>
                </button>
                {item.children && (activeView === item.id || item.children.some(child => child.id === activeView)) && (
                  <div className="ml-8 mt-1 space-y-1">
                    {item.children.map((child) => (
                      <button
                        key={child.id}
                        onClick={() => onViewChange(child.id)}
                        className={`w-full text-left px-4 py-2 text-sm rounded-lg transition-colors ${
                          activeView === child.id
                            ? 'bg-primary/20 text-primary font-medium'
                            : 'text-sidebar-foreground hover:bg-sidebar-accent'
                        }`}
                      >
                        {child.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>
        </div>
      </aside>

      {/* 主内容区 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* 顶部工具栏 */}
        <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-accent rounded-lg transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">2026-04-19</span>
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-medium">
              A
            </div>
          </div>
        </header>

        {/* 内容区域 */}
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
