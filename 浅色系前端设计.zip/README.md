
  # 浅色系前端设计

  This is a code bundle for 浅色系前端设计. The original project is available at https://www.figma.com/design/exNDdHtNW4HFXSMAfR2w1M/%E6%B5%85%E8%89%B2%E7%B3%BB%E5%89%8D%E7%AB%AF%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  